This is our answer to Question 1 of the NBA Basketball Analytics Track.

In this zip you will find:
Question_1.ipynb: Python Notebook
Question_1.pdf: PDF of python code
Question_1.py: Python code

We solved Question 1 four different ways, all resulting in a value of 5.88168644139%. The first two solutions were solved directly, and thus have extremely high (computer) precision. We believe our third solution (an approximation) is precise to up to 10 decimal points and fourth solution (simulation) is precise up to 3 decimal points. Both were used as ways to confirm the directly solved results of our first and second methods.
